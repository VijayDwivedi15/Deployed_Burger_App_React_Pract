import  axios from 'axios';

const instance = axios.create({
    baseURL :'https://react-my-burger-app-1170c.firebaseio.com/'
});

export default instance;     