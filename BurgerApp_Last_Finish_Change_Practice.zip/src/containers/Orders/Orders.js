import React, { useEffect } from 'react';
import Order from '../../components/Order/Order';
import axios from '../../axios-orders';
import withErrorHandler from '../../hoc/withErrorHandler/withErrorHandler';



//-------For Order fetch vai redux------START

import * as actions from '../../store/actions/index';
import {connect} from 'react-redux';
import Spinner from '../../components/UI/Spinner/Spinner';


//-------For Order fetch vai redux------END  //

const orders = props => {

    const {onFetchOrders} =props;


    useEffect(() => {
        onFetchOrders(props.token,props.userId);
        
    },[onFetchOrders]);
   

    // const removeOrderHandler = OrderId => {
    //    alert(OrderId);
    //    axios.delete('/orders/' + OrderId)
    //    .then(response => {
    //        console.log(response);
    //    }).catch(err => {
    //        console.log(err);
    //    });
    //   };
    
        let orders =<Spinner/>;
        let finalorders = null

        

       
            if(!props.loading )
            {
                orders = props.orders.map(order => (
                        <Order 
                            key={order.id}
                            ingredients={order.ingredients}
                            price={order.price} 
                             />
                             //clicked ={removeOrderHandler.bind(this, order.id)}
                            
                            
                    ));

                    if(orders.length>0)
                    {
                        finalorders = orders
                        
                    }

                    else
                    {
                        
                        finalorders = <center><h2><b style={{textAlign:"center",color:"red"}}>No Orders Found !</b></h2></center> 
                    }

                  

                   
                    
            }

            
        return (
            
            <div>
                {finalorders}
            </div>
        );
    
}

//--------for order fetch via redux---

const mapStateToProps = state => {
    return {
        orders : state.order.orders,
        loading : state.order.loading,
        token: state.auth.token ,
        userId : state.auth.userId
    }
}

const mapDispatchToProps = dispatch => {
    return {
        onFetchOrders : (token,userId) => dispatch(actions.fetchOrders(token,userId))
    };
};

export default connect(mapStateToProps,mapDispatchToProps) (withErrorHandler(orders, axios));